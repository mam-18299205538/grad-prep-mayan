#!/usr/bin/env bash
set -u
ROOT=/root/autodl-tmp/FairFAL
SEED="$1"
for BETA in 0.1 100; do
  if [ "$BETA" = "0.1" ]; then TAG=beta0p1; else TAG=beta100; fi
  RUNID="fmnist_"$TAG"_seed"$SEED"_20261015T1039_ca14e07"
  LOGDIR="/root/autodl-tmp/logs/$RUNID"
  OUTDIR="/root/autodl-tmp/results/$RUNID"
  ARCHDIR=/root/autodl-tmp/archives/fmnist_lt
  mkdir -p "$LOGDIR" "$OUTDIR" "$ARCHDIR"
  if [ -e "$LOGDIR/$RUNID.started" ]; then echo "REFUSE_DUPLICATE $RUNID"; exit 70; fi
  touch "$LOGDIR/$RUNID.started"
  cd "$ROOT" || exit 90
  { echo "run_id=$RUNID"; echo "seed=$SEED beta=$BETA ratios=0.05:0.45 step=0.05 rounds=100"; date -Is; git rev-parse HEAD; python --version; } > "$LOGDIR/$RUNID.manifest"
  python -u main.py --gpu 0 --dataset fmnist_lt --dd_beta "$BETA" --imb_ratio 0.05 --model cnn4conv --al_method fairfal --query_model_mode dir_balance --num_users 10 --frac 1.0 --local_ep 5 --rounds 100 --seed "$SEED" --query_ratio 0.05 --resume_ratio 0.05 --end_ratio 0.45 --data_dir /root/autodl-tmp/datasets --save_dir "$OUTDIR" --custom_name "$RUNID" > "$LOGDIR/$RUNID.log" 2>&1
  RC=$?; echo "$RC" > "$LOGDIR/$RUNID.exit_status"
  if [ "$RC" -ne 0 ]; then echo "TRAIN_FAIL rc=$RC run=$RUNID"; exit "$RC"; fi
  OK=1
  for R in 0.050 0.100 0.150 0.200 0.250 0.300 0.350 0.400 0.450; do
    CSV=$(find "$OUTDIR" -type f -path "*/label_ratio$R/$RUNID/results.csv" -print -quit)
    CKPT=$(find "$OUTDIR" -type f -path "*/label_ratio$R/$RUNID/last.pt" -print -quit)
    if [ -z "$CSV" ] || [ -z "$CKPT" ] || [ ! -s "$CKPT" ] || [ "$(wc -l < "$CSV")" -ne 101 ]; then echo "GATE_FAIL ratio=$R run=$RUNID"; OK=0; fi
  done
  if grep -Eiq 'Traceback|RuntimeError|OutOfMemoryError|CUDA out of memory|Killed process' "$LOGDIR/$RUNID.log"; then echo "FATAL_SCAN_FAIL run=$RUNID"; OK=0; fi
  if [ "$OK" -ne 1 ]; then echo "ACCEPTANCE_FAIL run=$RUNID"; exit 22; fi
  for R in 0.050 0.100 0.150 0.200 0.250 0.300 0.350 0.400 0.450; do
    CSV=$(find "$OUTDIR" -type f -path "*/label_ratio$R/$RUNID/results.csv" -print -quit)
    CKPT=$(find "$OUTDIR" -type f -path "*/label_ratio$R/$RUNID/last.pt" -print -quit)
    sha256sum "$CSV" "$CKPT" >> "$LOGDIR/$RUNID.manifest"
  done
  tar -czf "$ARCHDIR/$RUNID.tar.gz" -C "$OUTDIR" . -C "$LOGDIR" "$RUNID.log" "$RUNID.exit_status" "$RUNID.manifest"
  sha256sum "$ARCHDIR/$RUNID.tar.gz" > "$ARCHDIR/$RUNID.tar.gz.sha256"
  echo "SEED_CONFIG_ACCEPTED run=$RUNID archive=$ARCHDIR/$RUNID.tar.gz"
done
echo "SEED_LANE_COMPLETE seed=$SEED"
